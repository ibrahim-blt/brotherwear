//Hasan Danacı-262484023
//Halil İbrahim Bulut-262484048

(() => {
  if (window.location.protocol !== "file:") {
    return;
  }

  const filePath = decodeURIComponent(window.location.pathname).replaceAll("\\", "/");
  const lowerPath = filePath.toLocaleLowerCase("tr-TR");
  const marker = "/htdocs/";
  const markerIndex = lowerPath.indexOf(marker);

  if (markerIndex !== -1) {
    const projectPath = filePath.slice(markerIndex + marker.length).replace(/^\/+/, "");
    window.location.replace(`http://localhost/${projectPath}`);
    return;
  }

  alert("SQL bağlantısı için siteyi dosya olarak değil localhost üzerinden açmalısın. Örnek: http://localhost/proje2/kayit.html");
})();


const discountRate = 0.2;
const shippingPrice = 130;
const cashPaymentFee = 100;
const couponKey = "brotherwear-coupon";
const coupons = {
  BROTHER20: { title: "%20 indirim", type: "percent", value: 20 },
  HOSGELDIN10: { title: "%10 indirim", type: "percent", value: 10 },
  OKUL15: { title: "%15 okul indirimi", type: "percent", value: 15 },
};
const cartKey = "brotherwear-cart";
const usersKey = "brotherwear-users";
const currentUserKey = "brotherwear-current-user";
const currentUserIdKey = "brotherwear-current-user-id";
const ordersKey = "brotherwear-orders";
const addressesKey = "brotherwear-addresses";
const cardsKey = "brotherwear-cards";
const favoritesKey = "brotherwear-favorites";

const imageSet = {
  sweatshirt:
    "https://images.unsplash.com/photo-1578681994506-b8f463449011?auto=format&fit=crop&w=700&q=80",
  tshirt:
    "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=700&q=80",
  jean:
    "https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=700&q=80",
  bag:
    "https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&w=700&q=80",
  bomber:
    "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=700&q=80",
  pants:
    "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=700&q=80",
  hat:
    "https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=700&q=80",
  shirt:
    "https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=700&q=80",
};

const photoUrl = (photoId) =>
  `https://images.unsplash.com/${photoId}?auto=format&fit=crop&w=700&q=80`;

const productImages = {
  "nike-air-force-1-beyaz": "assets/nike-air-force-1-beyaz-1.webp",
  "adidas-campus-00s": "assets/adidas-campus-00s-1.webp",
  "nike-dunk-low-panda": "assets/nike-dunk-low-panda-1.webp",
  "adidas-yeezy-700-v3": "assets/adidas-yeezy-700-v3-1.webp",
  "nike-siyah-tisort": "assets/nike-siyah-tisort-1.webp",
  "nike-beyaz-tisort": "assets/nike-beyaz-tisort-1.webp",
  "nike-tm-tisort": "assets/nike-tm-tisort-1.webp",
  "nike-tm2-tisort": "assets/nike-tm2-tisort-1.webp",
  "nike-siyah-sort": "assets/nike-siyah-sort-1.webp",
  "nike-gri-sort": "assets/nike-gri-sort-1.webp",
  "nike-jordan-siyah-sort": "assets/nike-jordan-siyah-sort-1.webp",
  "nike-tm-sort": "assets/nike-tm-sort-1.webp",
  "nike-siyah-sweatshirt": "assets/nike-siyah-sweatshirt-1.webp",
  "nike-gri-sweatshirt": "assets/nike-gri-sweatshirt-1.webp",
  "nike-tm-siyah-sweatshirt": "assets/nike-tm-siyah-sweatshirt-1.webp",
  "nike-tm-gri-sweatshirt": "assets/nike-tm-gri-sweatshirt-1.webp",
  "baggy-siyah-pantolon": "assets/p1.webp",
  "baggy-buz-mavisi-pantolon": "assets/p2.webp",
  "baggy-antrasit-pantolon": "assets/p3.webp",
  "baggy-mavi-pantolon": "assets/p4.webp",
  "nike-siyah-esofman": "assets/nike-siyah-esofman-1.webp",
  "nike-gri-esofman": "assets/nike-gri-esofman-1.webp",
  "nike-gri-siyah-esofman": "assets/nike-gri-siyah-esofman-1.webp",
  "nike-pembe-esofman": "assets/nike-pembe-esofman-1.webp",
  "nike-siyah-ceket": "assets/nike-siyah-ceket-1.webp",
  "adidas-siyah-ceket": "assets/adidas-siyah-ceket-1.webp",
  "nike-siyah-mont": "assets/nike-siyah-mont-1.webp",
  "nike-gri-beyaz-mont": "assets/nike-gri-beyaz-mont-1.webp",
};

const productBackImages = {
  "nike-air-force-1-beyaz": "assets/nike-air-force-1-beyaz-2.webp",
  "adidas-campus-00s": "assets/adidas-campus-00s-2.webp",
  "nike-dunk-low-panda": "assets/nike-dunk-low-panda-2.webp",
  "adidas-yeezy-700-v3": "assets/adidas-yeezy-700-v3-2.webp",
  "nike-siyah-tisort": "assets/nike-siyah-tisort-2.webp",
  "nike-beyaz-tisort": "assets/nike-beyaz-tisort-2.webp",
  "nike-tm-tisort": "assets/nike-tm-tisort-2.webp",
  "nike-tm2-tisort": "assets/nike-tm2-tisort-2.webp",
  "nike-siyah-sort": "assets/nike-siyah-sort-2.webp",
  "nike-gri-sort": "assets/nike-gri-sort-2.webp",
  "nike-jordan-siyah-sort": "assets/nike-jordan-siyah-sort-2.webp",
  "nike-tm-sort": "assets/nike-tm-sort-2.webp",
  "nike-siyah-sweatshirt": "assets/nike-siyah-sweatshirt-2.webp",
  "nike-gri-sweatshirt": "assets/nike-gri-sweatshirt-2.webp",
  "nike-tm-siyah-sweatshirt": "assets/nike-tm-siyah-sweatshirt-2.webp",
  "nike-tm-gri-sweatshirt": "assets/nike-tm-gri-sweatshirt-2.webp",
  "baggy-siyah-pantolon": "assets/p1.webp",
  "baggy-buz-mavisi-pantolon": "assets/p2.webp",
  "baggy-antrasit-pantolon": "assets/p3.webp",
  "baggy-mavi-pantolon": "assets/p4.webp",
  "nike-siyah-esofman": "assets/nike-siyah-esofman-2.webp",
  "nike-gri-esofman": "assets/nike-gri-esofman-2.webp",
  "nike-gri-siyah-esofman": "assets/nike-gri-siyah-esofman-2.webp",
  "nike-pembe-esofman": "assets/nike-pembe-esofman-2.webp",
  "nike-siyah-ceket": "assets/nike-siyah-ceket-2.webp",
  "adidas-siyah-ceket": "assets/adidas-siyah-ceket-2.webp",
  "nike-siyah-mont": "assets/nike-siyah-mont-2.webp",
  "nike-gri-beyaz-mont": "assets/nike-gri-beyaz-mont-2.webp",
};

function escapeSvg(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function productShape(productItem, view) {
  const color = productItem.swatch;
  const stroke = "#1f2937";
  const name = escapeSvg(productItem.name);

  if (productItem.id.includes("jean") || productItem.id.includes("pantolon")) {
    return `
      <rect x="86" y="112" width="76" height="280" rx="18" fill="${color}" stroke="${stroke}" stroke-width="4"/>
      <rect x="178" y="112" width="76" height="280" rx="18" fill="${color}" stroke="${stroke}" stroke-width="4"/>
      <rect x="98" y="84" width="148" height="48" rx="12" fill="${color}" stroke="${stroke}" stroke-width="4"/>
      <line x1="170" y1="128" x2="170" y2="390" stroke="${stroke}" stroke-width="3"/>
      ${view === "front" ? '<path d="M122 132 C130 160 148 160 156 132" fill="none" stroke="#ffffff" stroke-width="4" opacity=".65"/>' : '<path d="M112 132 H236" stroke="#ffffff" stroke-width="5" opacity=".55"/>'}
      <text x="170" y="478" text-anchor="middle" font-size="18" fill="#4b5563">${name}</text>
    `;
  }

  const collar =
    view === "front"
      ? '<path d="M146 106 L170 140 L194 106" fill="#f8fafc" stroke="#1f2937" stroke-width="4"/>'
      : '<path d="M140 110 Q170 132 200 110" fill="none" stroke="#f8fafc" stroke-width="8"/>';
  const zipper = productItem.id.includes("bomber")
    ? '<line x1="170" y1="124" x2="170" y2="340" stroke="#f8fafc" stroke-width="5" opacity=".85"/>'
    : "";
  const buttonLine = productItem.id.includes("gomlek")
    ? '<line x1="170" y1="130" x2="170" y2="340" stroke="#f8fafc" stroke-width="4" opacity=".85"/><circle cx="170" cy="172" r="4" fill="#f8fafc"/><circle cx="170" cy="220" r="4" fill="#f8fafc"/><circle cx="170" cy="268" r="4" fill="#f8fafc"/>'
    : "";

  return `
    <path d="M102 120 L142 84 H198 L238 120 L282 188 L246 218 L222 170 V370 H118 V170 L94 218 L58 188 Z" fill="${color}" stroke="${stroke}" stroke-width="4"/>
    ${collar}
    ${zipper}
    ${buttonLine}
    ${view === "back" ? '<path d="M126 142 H214" stroke="#f8fafc" stroke-width="5" opacity=".55"/>' : ""}
    <text x="170" y="478" text-anchor="middle" font-size="18" fill="#4b5563">${name}</text>
  `;
}

function mockupDataUrl(productItem, view) {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="700" height="875" viewBox="0 0 340 500">
      <rect width="340" height="500" fill="#f5f7fb"/>
      <rect x="20" y="20" width="300" height="460" rx="18" fill="#ffffff" stroke="#d8dee8"/>
      ${productShape(productItem, view)}
    </svg>
  `;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

const products = [
  product("nike-air-force-1-beyaz", "Nike Air Force 1 Beyaz", "ayakkabi", "Ayakkabı", 2499, "Beyaz", "#f5f5f3"),
  product("adidas-campus-00s", "Adidas Campus 00's", "ayakkabi", "Ayakkabı", 2499, "Siyah", "#111111"),
  product("nike-dunk-low-panda", "Nike Dunk Low Panda", "ayakkabi", "Ayakkabı", 2499, "Siyah / beyaz", "#ededed"),
  product("adidas-yeezy-700-v3", "Adidas Yeezy 700 V3", "ayakkabi", "Ayakkabı", 2499, "Krem / beyaz", "#f2edcf"),
  product("nike-siyah-tisort", "Nike Siyah Tişört", "tisort", "Tişört", 279, "Siyah", "#111111"),
  product("nike-beyaz-tisort", "Nike Beyaz Tişört", "tisort", "Tişört", 279, "Beyaz", "#f7f7f2"),
  product("nike-tm-tisort", "Nike TM Tişört", "tisort", "Tişört", 279, "Siyah", "#111111"),
  product("nike-tm2-tisort", "Nike TM2 Tişört", "tisort", "Tişört", 279, "Beyaz", "#f7f7f2"),
  product("nike-siyah-sort", "Nike Siyah Şort", "sort", "Şort", 499, "Siyah", "#111111"),
  product("nike-gri-sort", "Nike Gri Şort", "sort", "Şort", 499, "Gri", "#a7a7a7"),
  product("nike-jordan-siyah-sort", "Nike Jordan Siyah Şort", "sort", "Şort", 499, "Siyah", "#111111"),
  product("nike-tm-sort", "Nike TM Şort", "sort", "Şort", 499, "Gri", "#b8b8b8"),
  product("nike-siyah-sweatshirt", "Nike Siyah Sweatshirt", "sweatshirt", "Sweatshirt", 599, "Siyah", "#111111"),
  product("nike-gri-sweatshirt", "Nike Gri Sweatshirt", "sweatshirt", "Sweatshirt", 599, "Gri", "#9b9b9b"),
  product("nike-tm-siyah-sweatshirt", "Nike TM Siyah Sweatshirt", "sweatshirt", "Sweatshirt", 599, "Siyah", "#111111"),
  product("nike-tm-gri-sweatshirt", "Nike TM Gri Sweatshirt", "sweatshirt", "Sweatshirt", 599, "Gri", "#aaaaaa"),
  product("baggy-siyah-pantolon", "Baggy Siyah Pantolon", "pantolon", "Pantolon", 749, "Siyah", "#111111"),
  product("baggy-buz-mavisi-pantolon", "Baggy Buz Mavisi Pantolon", "pantolon", "Pantolon", 749, "Buz mavisi", "#c9dce8"),
  product("baggy-antrasit-pantolon", "Baggy Antrasit Pantolon", "pantolon", "Pantolon", 749, "Antrasit", "#4b4b4b"),
  product("baggy-mavi-pantolon", "Baggy Mavi Pantolon", "pantolon", "Pantolon", 749, "Mavi", "#416f9f"),
  product("nike-siyah-esofman", "Nike Siyah Eşofman", "esofman", "Eşofman", 749, "Siyah", "#111111"),
  product("nike-gri-esofman", "Nike Gri Eşofman", "esofman", "Eşofman", 749, "Gri", "#c5c5c5"),
  product("nike-gri-siyah-esofman", "Nike Gri-Siyah Eşofman", "esofman", "Eşofman", 749, "Gri / siyah", "#666666"),
  product("nike-pembe-esofman", "Nike Pembe Eşofman", "esofman", "Eşofman", 749, "Pembe", "#dc6f9f"),
  product("nike-siyah-ceket", "Nike Siyah Ceket", "ceket", "Ceket", 999, "Siyah", "#111111"),
  product("adidas-siyah-ceket", "Adidas Siyah Ceket", "ceket", "Ceket", 999, "Siyah", "#111111"),
  product("nike-siyah-mont", "Nike Siyah Mont", "mont", "Mont", 1499, "Siyah", "#111111"),
  product("nike-gri-beyaz-mont", "Nike Gri-Beyaz Mont", "mont", "Mont", 1499, "Gri / beyaz", "#c6c8ca"),
];

let cart = readCart();
let activeFilter = "all";
let activeSearchTerm = "";
if (localStorage.getItem(cartKey)) {
  localStorage.removeItem(cartKey);
}

const grid = document.querySelector("#product-grid");
const cartCount = document.querySelector("#cart-count");
const cartItems = document.querySelector("#cart-items");
const cartTotal = document.querySelector("#cart-total");
const checkoutItems = document.querySelector("#checkout-items");
const checkoutTotal = document.querySelector("#checkout-total");
const filterButtons = document.querySelectorAll(".filter-button");
const searchForms = document.querySelectorAll(".site-search");
const searchStatus = document.querySelector("#search-status");
const detailRoot = document.querySelector("#product-detail");
const profileRoot = document.querySelector("#profile-root");
const successRoot = document.querySelector("#success-root");

function product(id, name, category, label, price, color, swatch, image) {
  const baseProduct = { id, name, category, label, price, color, swatch, image: productImages[id] || image };
  const hasSizes = category !== "aksesuar";

  if (!hasSizes) {
    return { ...baseProduct, hasSizes, sizes: [], sizeLabel: "", frontImage: baseProduct.image };
  }

  if (category === "ayakkabi") {
    return {
      ...baseProduct,
      hasSizes,
      sizes: ["36", "37", "38", "39", "40", "41", "42", "43", "44", "45"],
      sizeLabel: "Numara",
      frontImage: baseProduct.image,
      backImage: productBackImages[id],
    };
  }

  if (productBackImages[id]) {
    return {
      ...baseProduct,
      hasSizes,
      sizes: ["S", "M", "L", "XL"],
      sizeLabel: "Beden",
      frontImage: baseProduct.image,
      backImage: productBackImages[id],
    };
  }

  if (id === "siyah-bomber-ceket" || id === "koyu-mavi-bomber-ceket") {
    return {
      ...baseProduct,
      hasSizes,
      sizes: ["S", "M", "L", "XL"],
      sizeLabel: "Beden",
      frontImage: baseProduct.image,
      backImage: mockupDataUrl(baseProduct, "back"),
    };
  }

  return {
    ...baseProduct,
    hasSizes,
    sizes: ["S", "M", "L", "XL"],
    sizeLabel: "Beden",
    image: mockupDataUrl(baseProduct, "front"),
    frontImage: mockupDataUrl(baseProduct, "front"),
    backImage: mockupDataUrl(baseProduct, "back"),
  };
}


function cartStorageKey() {
  const currentUser = getCurrentUser();

  if (!currentUser) {
    return `${cartKey}-guest`;
  }

  return `${cartKey}-${currentUser}`;
}

function readCart() {
  const savedCart = localStorage.getItem(cartStorageKey());

  if (!savedCart) {
    return [];
  }

  try {
    const parsedCart = JSON.parse(savedCart);
    const migratedCart = parsedCart.map((item) => {
      if (item.name === "Ceket Gömlek") {
        return { ...item, name: "Oversize Bomber Ceket", id: "oversize-bomber-ceket" };
      }

      return item;
    });

    if (JSON.stringify(parsedCart) !== JSON.stringify(migratedCart)) {
      localStorage.setItem(cartStorageKey(), JSON.stringify(migratedCart));
    }

    return migratedCart;
  } catch {
    return [];
  }
}

function readUsers() {
  try {
    return JSON.parse(localStorage.getItem(usersKey)) || [];
  } catch {
    return [];
  }
}

function saveUsers(users) {
  localStorage.setItem(usersKey, JSON.stringify(users));
}

function getCurrentUserId() {
  return localStorage.getItem(currentUserIdKey) || "";
}

function setCurrentUser(username, userId = "") {
  localStorage.setItem(currentUserKey, username);

  if (userId) {
    localStorage.setItem(currentUserIdKey, String(userId));
  }

  reloadCartForCurrentUser();
}

async function sqlRequest(action, data = null, method = "POST") {
  const options = {
    method,
    headers: {
      "Content-Type": "application/json",
    },
  };

  if (data) {
    options.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(`backend/api.php?action=${encodeURIComponent(action)}`, options);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.warn("SQL bağlantısı kullanılamadı:", error);
    return {
      success: false,
      offline: true,
      message: "SQL bağlantısı kurulamadı. Proje XAMPP/localhost üzerinden çalıştırılmalı.",
    };
  }
}

function sqlUserPayload(extra = {}) {
  const kullaniciId = Number(getCurrentUserId());

  return {
    kullanici_id: kullaniciId,
    ...extra,
  };
}

function getCurrentUser() {
  return localStorage.getItem(currentUserKey) || "";
}

function userDataKey(baseKey) {
  return `${baseKey}-${getCurrentUser()}`;
}

function readUserData(baseKey) {
  if (!getCurrentUser()) {
    return [];
  }

  try {
    return JSON.parse(localStorage.getItem(userDataKey(baseKey))) || [];
  } catch {
    return [];
  }
}

function saveUserData(baseKey, data) {
  if (!getCurrentUser()) {
    return;
  }

  localStorage.setItem(userDataKey(baseKey), JSON.stringify(data));
}

function safeText(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function orderItemText(item) {
  const sizeText = item.size ? ` (${safeText(item.sizeLabel || "Beden")}: ${safeText(item.size)})` : "";
  return `${safeText(item.name)}${sizeText}`;
}

function favoriteProductIds() {
  return readUserData(favoritesKey);
}

function isFavorite(productId) {
  return favoriteProductIds().includes(productId);
}


function saveCart() {
  localStorage.setItem(cartStorageKey(), JSON.stringify(cart));
}

function reloadCartForCurrentUser() {
  cart = readCart();
  renderCart();
  renderCheckout();
}

function salePrice(productItem) {
  return Math.round((productItem.price || 0) * (1 - discountRate));
}

function formatPrice(value) {
  return `${value.toLocaleString("tr-TR")} TL`;
}

function normalize(value) {
  return String(value || "")
    .toLocaleLowerCase("tr-TR")
    .trim();
}

function cartSum() {
  return cart.reduce((sum, item) => sum + salePrice(item), 0);
}

function activeCoupon() {
  const code = String(localStorage.getItem(couponKey) || "").trim().toLocaleUpperCase("tr-TR");
  const coupon = coupons[code];

  if (!coupon) {
    return null;
  }

  return { code, ...coupon };
}

function couponDiscountAmount() {
  const coupon = activeCoupon();

  if (!coupon || cart.length === 0) {
    return 0;
  }

  if (coupon.type === "percent") {
    return Math.min(cartSum(), Math.round((cartSum() * coupon.value) / 100));
  }

  return 0;
}

function paymentExtraFee() {
  const selectedPayment = document.querySelector('input[name="payment-method"]:checked');
  return selectedPayment && selectedPayment.closest(".cash-option") ? cashPaymentFee : 0;
}

function checkoutFinalTotal() {
  const discountedSubtotal = Math.max(0, cartSum() - couponDiscountAmount());
  return discountedSubtotal + shippingPrice + paymentExtraFee();
}

function renderCouponAreas(message = "") {
  const coupon = activeCoupon();
  const discount = couponDiscountAmount();
  const extraFee = paymentExtraFee();

  document.querySelectorAll(".coupon-code-input").forEach((input) => {
    input.value = coupon ? coupon.code : "";
  });

  document.querySelectorAll(".coupon-status").forEach((status) => {
    if (message) {
      status.textContent = message;
    } else if (coupon) {
      status.textContent = `${coupon.code} uygulandı: ${coupon.title}.`;
    } else {
      status.textContent = "Kupon kodu olarak BROTHER20, HOSGELDIN10 veya OKUL15 deneyebilirsin.";
    }
  });

  const cartDiscountRow = document.querySelector("#cart-discount-row");
  const cartDiscountAmount = document.querySelector("#cart-discount-amount");
  if (cartDiscountRow && cartDiscountAmount) {
    cartDiscountRow.classList.toggle("is-hidden", !coupon || discount <= 0);
    cartDiscountAmount.textContent = `-${formatPrice(discount)}`;
  }

  const checkoutDiscountRow = document.querySelector("#checkout-discount-row");
  const checkoutDiscountAmount = document.querySelector("#checkout-discount-amount");
  if (checkoutDiscountRow && checkoutDiscountAmount) {
    checkoutDiscountRow.classList.toggle("is-hidden", !coupon || discount <= 0);
    checkoutDiscountAmount.textContent = `-${formatPrice(discount)}`;
  }

  const extraRow = document.querySelector("#payment-extra-row");
  const extraTotal = document.querySelector("#payment-extra-total");
  if (extraRow && extraTotal) {
    extraRow.classList.toggle("is-hidden", extraFee <= 0);
    extraTotal.textContent = formatPrice(extraFee);
  }

  const finalTotal = document.querySelector("#checkout-final-total");
  if (finalTotal) {
    finalTotal.textContent = formatPrice(checkoutFinalTotal());
  }
}

function setupCouponForms() {
  document.querySelectorAll(".coupon-form").forEach((form) => {
    if (form.dataset.ready === "true") {
      return;
    }

    form.dataset.ready = "true";

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const input = form.querySelector(".coupon-code-input");
      const code = String(input?.value || "").trim().toLocaleUpperCase("tr-TR");

      if (!code || !coupons[code]) {
        localStorage.removeItem(couponKey);
        renderCart();
        renderCheckout();
        renderCouponAreas("Kupon kodu geçersiz. BROTHER20, HOSGELDIN10 veya OKUL15 deneyebilirsin.");
        return;
      }

      localStorage.setItem(couponKey, code);
      renderCart();
      renderCheckout();
      renderCouponAreas(`${code} kuponu uygulandı.`);
    });

    form.querySelector(".coupon-clear-button")?.addEventListener("click", () => {
      localStorage.removeItem(couponKey);
      renderCart();
      renderCheckout();
      renderCouponAreas("Kupon temizlendi.");
    });
  });

  renderCouponAreas();
}

function productSearchText(productItem) {
  return normalize(`${productItem.name} ${productItem.label} ${productItem.category} ${productItem.color}`);
}

function updateCartCount() {
  if (cartCount) {
    cartCount.textContent = cart.length;
  }
}

function updateAuthLinks() {
  const currentUser = getCurrentUser();

  document.querySelectorAll(".auth-link").forEach((link) => {
    if (currentUser) {
      link.textContent = "Profilim";
      link.href = "profil.html";
      link.setAttribute("aria-label", `${currentUser} profil sayfası`);
    } else {
      link.textContent = "Oturum aç";
      link.href = "kayit.html";
      link.setAttribute("aria-label", "Oturum aç");
    }
  });
}

function renderProducts(filter = activeFilter, searchTerm = activeSearchTerm) {
  if (!grid) {
    return;
  }

  activeFilter = filter;
  activeSearchTerm = normalize(searchTerm);

  const visibleProducts = products.filter((productItem) => {
    const matchesFilter = activeFilter === "all" || productItem.category === activeFilter;
    const matchesSearch =
      activeSearchTerm.length === 0 || productSearchText(productItem).includes(activeSearchTerm);

    return matchesFilter && matchesSearch;
  });

  if (visibleProducts.length === 0) {
    grid.innerHTML = `
      <div class="no-results">
        <h3>Ürün bulunamadı</h3>
        <p>Aradığın kelimeyle eşleşen ürün yok. Başka bir renk, kategori veya ürün adı deneyebilirsin.</p>
      </div>
    `;
  } else {
    grid.innerHTML = visibleProducts
      .map((productItem) => {
        const favoriteClass = isFavorite(productItem.id) ? " active" : "";
        const favoriteText = isFavorite(productItem.id) ? "Favorilerden çıkar" : "Favorilere ekle";
        const cartButton = productItem.hasSizes
          ? `<button class="button primary choose-size-button" type="button" data-id="${productItem.id}">${productItem.sizeLabel} seç</button>`
          : `<button class="button primary add-button" type="button" data-id="${productItem.id}">Sepete ekle</button>`;

        return `
          <article class="product-card" data-detail-id="${productItem.id}" data-category="${productItem.category}" tabindex="0" aria-label="${productItem.name} detayını aç">
            <a class="product-image product-image-link" href="detaylar.html?id=${productItem.id}" aria-label="${productItem.name} detayını gör">
              <span class="discount-badge">İndirim</span>
              <img class="${productBackImages[productItem.id] ? "contain-image" : ""}" src="${productItem.image}" alt="${productItem.name}" />
            </a>
            <div class="product-info">
              <div>
                <h3><a href="detaylar.html?id=${productItem.id}">${productItem.name}</a></h3>
                <div class="product-meta">
                  <span>${productItem.label}</span>
                  <span class="color-chip">
                    <span style="background:${productItem.swatch}"></span>
                    ${productItem.color}
                  </span>
                </div>
                <div class="price-row">
                  <span class="old-price">${formatPrice(productItem.price)}</span>
                  <strong class="price">${formatPrice(salePrice(productItem))}</strong>
                </div>
              </div>
              <button class="favorite-button${favoriteClass}" type="button" data-id="${productItem.id}">
                ${favoriteText}
              </button>
              ${cartButton}
            </div>
          </article>
        `;
      })
      .join("");
  }

  if (searchStatus) {
    if (activeSearchTerm) {
      searchStatus.textContent = `"${searchTerm}" araması için ${visibleProducts.length} ürün bulundu.`;
    } else {
      searchStatus.textContent = "Tüm ürünlerde %20 indirim geçerlidir.";
    }
  }

  document.querySelectorAll(".add-button").forEach((button) => {
    button.addEventListener("click", () => addToCart(button.dataset.id));
  });

  document.querySelectorAll(".choose-size-button").forEach((button) => {
    button.addEventListener("click", () => {
      window.location.href = `detaylar.html?id=${button.dataset.id}`;
    });
  });

  document.querySelectorAll(".favorite-button[data-id]").forEach((button) => {
    button.addEventListener("click", () => toggleFavorite(button.dataset.id));
  });

  document.querySelectorAll(".product-card").forEach((card) => {
    card.addEventListener("click", (event) => {
      if (event.target.closest("a, button")) {
        return;
      }

      window.location.href = `detaylar.html?id=${card.dataset.detailId}`;
    });

    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        window.location.href = `detaylar.html?id=${card.dataset.detailId}`;
      }
    });
  });
}

function renderCart() {
  updateCartCount();

  if (!cartItems || !cartTotal) {
    renderCouponAreas();
    return;
  }

  if (cart.length === 0) {
    cartItems.innerHTML = '<li class="empty-cart">Sepetiniz henüz boş.</li>';
    cartTotal.textContent = "0 TL";
    renderCouponAreas();
    return;
  }

  cartItems.innerHTML = cart
    .map(
      (item, index) => `
        <li class="cart-item">
          <div class="cart-item-info">
            <span>${safeText(item.name)}</span>
            ${item.size ? `<small class="cart-item-size">${safeText(item.sizeLabel || "Beden")}: ${safeText(item.size)}</small>` : ""}
            <strong>${formatPrice(salePrice(item))}</strong>
          </div>
          <button class="cart-remove-button" type="button" data-index="${index}" aria-label="${safeText(item.name)} ürününü sepetten sil">
            Sil
          </button>
        </li>
      `
    )
    .join("");

  document.querySelectorAll(".cart-remove-button").forEach((button) => {
    button.addEventListener("click", () => removeFromCart(Number(button.dataset.index)));
  });

  cartTotal.textContent = formatPrice(Math.max(0, cartSum() - couponDiscountAmount()));
  renderCouponAreas();
}

function removeFromCart(index) {
  if (Number.isNaN(index) || index < 0 || index >= cart.length) {
    return;
  }

  const removedItem = cart[index];
  cart.splice(index, 1);
  saveCart();
  renderCart();
  renderCheckout();

  if (getCurrentUserId() && removedItem) {
    sqlRequest("sepet_sil", sqlUserPayload({
      urun_kodu: removedItem.id,
      beden_numara: removedItem.size || "",
    }));
  }
}

function toggleFavorite(productId) {
  if (!getCurrentUser()) {
    alert("Favorilere ürün eklemek için önce giriş yapmalısınız.");
    window.location.href = "kayit.html";
    return;
  }

  const favorites = favoriteProductIds();
  const saved = favorites.includes(productId);
  const updatedFavorites = saved
    ? favorites.filter((item) => item !== productId)
    : [...favorites, productId];

  saveUserData(favoritesKey, updatedFavorites);

  if (getCurrentUserId()) {
    sqlRequest(saved ? "favori_sil" : "favori_ekle", sqlUserPayload({
      urun_kodu: productId,
    }));
  }

  renderProducts(activeFilter, activeSearchTerm);
  renderProductDetail();
  renderProfile();
}

function saveOrder() {
  const orders = readUserData(ordersKey);
  const order = {
    id: Date.now(),
    no: `BW-${String(Date.now()).slice(-6)}`,
    date: new Date().toLocaleDateString("tr-TR"),
    items: cart.map((item) => ({ ...item, salePrice: salePrice(item) })),
    total: cartSum(),
  };

  saveUserData(ordersKey, [order, ...orders]);
}

function renderCheckout() {
  if (!checkoutItems || !checkoutTotal) {
    renderCouponAreas();
    return;
  }

  if (cart.length === 0) {
    checkoutItems.innerHTML = '<li class="empty-cart">Ödeme için sepetinizde ürün yok.</li>';
    checkoutTotal.textContent = "0 TL";
    renderCouponAreas();
    return;
  }

  checkoutItems.innerHTML = cart
    .map(
      (item) => `
        <li>
          <span>
            ${safeText(item.name)}
            ${item.size ? `<small class="checkout-item-size">${safeText(item.sizeLabel || "Beden")}: ${safeText(item.size)}</small>` : ""}
          </span>
          <strong>${formatPrice(salePrice(item))}</strong>
        </li>
      `
    )
    .join("");

  checkoutTotal.textContent = formatPrice(cartSum());
  renderCouponAreas();
}

function addToCart(productId, selectedSize = "") {
  const selectedProduct = products.find((productItem) => productItem.id === productId);

  if (!selectedProduct) {
    return;
  }

  if (selectedProduct.hasSizes && !selectedSize) {
    alert(`${selectedProduct.sizeLabel} seçmeden sepete ekleyemezsiniz.`);
    return;
  }

  const cartItem = {
    id: selectedProduct.id,
    name: selectedProduct.name,
    price: selectedProduct.price,
    size: selectedSize,
    sizeLabel: selectedProduct.hasSizes ? selectedProduct.sizeLabel : "",
  };

  cart.push(cartItem);
  saveCart();
  renderCart();
  renderCheckout();

  if (getCurrentUserId()) {
    sqlRequest("sepet_ekle", sqlUserPayload({
      urun_kodu: selectedProduct.id,
      beden_numara: selectedSize,
      adet: 1,
    }));
  }
}

function renderProductDetail() {
  if (!detailRoot) {
    return;
  }

  const params = new URLSearchParams(window.location.search);
  const productId = params.get("id");
  const selectedProduct = products.find((productItem) => productItem.id === productId);

  if (!selectedProduct) {
    detailRoot.innerHTML = `
      <section class="page-hero compact">
        <p class="eyebrow">Ürün detayı</p>
        <h1>Ürün bulunamadı</h1>
        <p>Aradığın ürün bulunamadı. Ürünler sayfasına geri dönebilirsin.</p>
        <a class="button primary" href="anasayfa.html#products">Ürünlere dön</a>
      </section>
    `;
    return;
  }

  document.title = `${selectedProduct.name} | BrotherWear`;

  const galleryImages =
    selectedProduct.category === "ayakkabi" ||
    selectedProduct.category === "sort" ||
    selectedProduct.category === "sweatshirt"
      ? [
          ["1. görünüm", selectedProduct.frontImage],
          ["2. görünüm", selectedProduct.backImage],
        ]
      : selectedProduct.hasSizes
        ? [
            ["Ön görünüm", selectedProduct.frontImage],
            ["Arka görünüm", selectedProduct.backImage],
          ]
        : [["Ürün görseli", selectedProduct.frontImage]];

  detailRoot.innerHTML = `
    <section class="detail-section">
      <div class="detail-gallery">
        ${galleryImages
          .map(
            ([label, image]) => `
              <figure class="detail-photo">
                <span class="discount-badge">İndirim</span>
                <img class="${productBackImages[selectedProduct.id] ? "contain-image" : ""}" src="${image}" alt="${selectedProduct.name} ${label}" />
              </figure>
            `
          )
          .join("")}
      </div>
      <div class="detail-info">
        <p class="eyebrow">${selectedProduct.label}</p>
        <h1>${selectedProduct.name}</h1>
        <p class="detail-summary">
          ${selectedProduct.color} renk seçeneğiyle BrotherWear koleksiyonunda yer alan bu üründe %20 indirim geçerlidir.
        </p>
        <div class="detail-price">
          <span class="old-price">${formatPrice(selectedProduct.price)}</span>
          <strong class="price">${formatPrice(salePrice(selectedProduct))}</strong>
        </div>
        <div class="detail-color">
          <span>Renk</span>
          <strong><i style="background:${selectedProduct.swatch}"></i>${selectedProduct.color}</strong>
        </div>
        ${
          selectedProduct.hasSizes
            ? `
              <div class="size-panel">
                <span>${selectedProduct.sizeLabel}</span>
                <div class="size-options" aria-label="${selectedProduct.sizeLabel} seçimi">
                  ${selectedProduct.sizes
                    .map((size) => `<button class="size-button" type="button" data-size="${size}">${size}</button>`)
                    .join("")}
                </div>
                <p class="size-warning" id="size-warning">Sepete eklemek için ${selectedProduct.sizeLabel.toLocaleLowerCase("tr-TR")} seçiniz.</p>
              </div>
            `
            : '<p class="accessory-note">Bu üründe beden seçimi gerekmez.</p>'
        }
        <div class="detail-actions">
          <button class="button primary detail-add-button" type="button" data-id="${selectedProduct.id}">
            Sepete ekle
          </button>
          <button class="button secondary favorite-button detail-favorite-button${isFavorite(selectedProduct.id) ? " active" : ""}" type="button" data-id="${selectedProduct.id}">
            ${isFavorite(selectedProduct.id) ? "Favorilerden çıkar" : "Favorilere ekle"}
          </button>
          <a class="button secondary" href="anasayfa.html#products">Alışverişe devam et</a>
        </div>
      </div>
    </section>
  `;

  detailRoot.querySelector(".detail-add-button")?.addEventListener("click", () => {
    const selectedSize = detailRoot.querySelector(".size-button.active")?.dataset.size || "";
    const warning = detailRoot.querySelector("#size-warning");

    if (selectedProduct.hasSizes && !selectedSize) {
      if (warning) {
        warning.textContent = `${selectedProduct.sizeLabel} seçmeden sepete ekleyemezsiniz.`;
        warning.classList.add("error");
      }
      return;
    }

    addToCart(selectedProduct.id, selectedSize);
    if (warning) {
      warning.textContent = "Ürün seçilen beden/numara ile sepete eklendi.";
      warning.classList.remove("error");
      warning.classList.add("success");
    }
  });

  detailRoot.querySelector(".detail-favorite-button")?.addEventListener("click", () => {
    toggleFavorite(selectedProduct.id);
  });

  detailRoot.querySelectorAll(".size-button").forEach((button) => {
    button.addEventListener("click", () => {
      detailRoot.querySelectorAll(".size-button").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      const warning = detailRoot.querySelector("#size-warning");
      if (warning) {
        warning.textContent = `${selectedProduct.sizeLabel}: ${button.dataset.size} seçildi.`;
        warning.classList.remove("error");
        warning.classList.add("success");
      }
    });
  });
}

function renderProfile() {
  if (!profileRoot) {
    return;
  }

  const currentUser = getCurrentUser();

  try {
     if (!currentUser) {
    profileRoot.innerHTML = `
      <section class="page-hero compact">
        <p class="eyebrow">Profil</p>
        <h1>Profil sayfası için giriş yapmalısınız</h1>
        <p>Siparişlerinizi, adreslerinizi, favorilerinizi ve kayıtlı kartlarınızı görmek için oturum açın.</p>
        <a class="button primary" href="kayit.html">Giriş yap veya kaydol</a>
        ttdutdfjsyfyfyay
      </section>
    `;
    return;
  }
  } catch (error) {
    console.log("hata mesajınız:${error}")
  }
 

  const orders = readUserData(ordersKey);
  const addresses = readUserData(addressesKey);
  const cards = readUserData(cardsKey);
  const favorites = favoriteProductIds()
    .map((id) => products.find((productItem) => productItem.id === id))
    .filter(Boolean);

  profileRoot.innerHTML = `
    <section class="profile-dashboard">
      <aside class="profile-sidebar">
        <p class="eyebrow">Hesabım</p>
        <h2>Merhaba, ${safeText(currentUser)}</h2>
        <p>Buradan siparişlerini, adreslerini, favorilerini ve kayıtlı kartlarını yönetebilirsin.</p>
        <nav class="profile-menu" aria-label="Profil menüsü">
          <a href="#siparislerim">Siparişlerim</a>
          <a href="#adreslerim">Adreslerim</a>
          <a href="#favorilerim">Favorilerim</a>
          <a href="#kartlarim">Kayıtlı kartlarım</a>
        </nav>
        <button class="button secondary logout-button" type="button">Çıkış yap</button>
      </aside>

      <div class="profile-content">
        <article class="profile-card" id="siparislerim">
          <div class="profile-card-title">
            <p class="eyebrow">Alışveriş geçmişi</p>
            <h2>Siparişlerim</h2>
          </div>
          <div class="profile-list">
            ${
              orders.length
                ? orders
                    .map(
                      (order) => `
                        <div class="profile-list-item">
                          <div>
                            <strong>${safeText(order.no)}</strong>
                            <p>${safeText(order.date)} tarihinde ${order.items.length} ürün sipariş edildi.</p>
                            <small>${order.items.map(orderItemText).join(", ")}</small>
                            ${order.coupon ? `<small>Kupon: ${safeText(order.coupon.code)} / -${formatPrice(order.discount || 0)}</small>` : ""}
                          </div>
                          <span class="profile-price">${formatPrice(order.total)}</span>
                        </div>
                      `
                    )
                    .join("")
                : '<p class="empty-profile-text">Henüz siparişiniz yok. Ödeme tamamladığınızda siparişler burada görünür.</p>'
            }
          </div>
        </article>

        <article class="profile-card" id="adreslerim">
          <div class="profile-card-title">
            <p class="eyebrow">Teslimat bilgileri</p>
            <h2>Adreslerim</h2>
          </div>
          <form class="profile-form address-form">
            <input type="text" name="title" placeholder="Adres başlığı: Ev, okul..." required />
            <textarea name="address" placeholder="Adresinizi yazın" required></textarea>
            <button class="button primary" type="submit">Adresi kaydet</button>
          </form>
          <div class="profile-list">
            ${
              addresses.length
                ? addresses
                    .map(
                      (address) => `
                        <div class="profile-list-item">
                          <div>
                            <strong>${safeText(address.title)}</strong>
                            <p>${safeText(address.address)}</p>
                          </div>
                          <button class="small-delete-button" type="button" data-address-id="${address.id}">Sil</button>
                        </div>
                      `
                    )
                    .join("")
                : '<p class="empty-profile-text">Kayıtlı adresiniz yok.</p>'
            }
          </div>
        </article>

        <article class="profile-card" id="favorilerim">
          <div class="profile-card-title">
            <p class="eyebrow">Beğenilen ürünler</p>
            <h2>Favorilerim</h2>
          </div>
          <div class="favorite-grid">
            ${
              favorites.length
                ? favorites
                    .map(
                      (productItem) => `
                        <div class="favorite-card">
                          <img src="${productItem.image}" alt="${safeText(productItem.name)}" />
                          <div>
                            <strong>${safeText(productItem.name)}</strong>
                            <span>${formatPrice(salePrice(productItem))}</span>
                          </div>
                          <div class="favorite-card-actions">
                            <a class="button secondary" href="detaylar.html?id=${productItem.id}">Detay</a>
                            <button class="small-delete-button" type="button" data-favorite-id="${productItem.id}">Sil</button>
                          </div>
                        </div>
                      `
                    )
                    .join("")
                : '<p class="empty-profile-text">Henüz favori ürününüz yok. Ürün kartlarındaki favori butonuyla ekleyebilirsiniz.</p>'
            }
          </div>
        </article>

        <article class="profile-card" id="kartlarim">
          <div class="profile-card-title">
            <p class="eyebrow">Ödeme bilgileri</p>
            <h2>Kayıtlı kartlarım</h2>
          </div>
          <form class="profile-form card-form">
            <input type="text" name="cardName" placeholder="Kart adı: Kişisel kart" required />
            <input type="text" name="cardNumber" inputmode="numeric" placeholder="Kart numarası" required />
            <button class="button primary" type="submit">Kartı kaydet</button>
          </form>
          <p class="profile-note">Güvenlik için kartın sadece son 4 hanesi kaydedilir.</p>
          <div class="profile-list">
            ${
              cards.length
                ? cards
                    .map(
                      (card) => `
                        <div class="profile-list-item">
                          <div>
                            <strong>${safeText(card.cardName)}</strong>
                            <p>**** **** **** ${safeText(card.last4)}</p>
                          </div>
                          <button class="small-delete-button" type="button" data-card-id="${card.id}">Sil</button>
                        </div>
                      `
                    )
                    .join("")
                : '<p class="empty-profile-text">Kayıtlı kartınız yok.</p>'
            }
          </div>
        </article>
      </div>
    </section>
  `;

  profileRoot.querySelector(".logout-button")?.addEventListener("click", () => {
    localStorage.removeItem(currentUserKey);
    localStorage.removeItem(currentUserIdKey);
    cart = [];
    saveCart();
    reloadCartForCurrentUser();
    updateAuthLinks();
    window.location.href = "kayit.html";
  });

  profileRoot.querySelector(".address-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const addresses = readUserData(addressesKey);
    const newAddress = {
      id: Date.now(),
      title: String(formData.get("title") || "").trim(),
      address: String(formData.get("address") || "").trim(),
    };

    if (getCurrentUserId()) {
      const sqlAddress = await sqlRequest("adres_ekle", sqlUserPayload({
        ad_soyad: newAddress.title,
        telefon: "",
        il: "",
        ilce: "",
        adres_detay: newAddress.address,
      }));

      if (sqlAddress.success) {
        newAddress.sqlId = sqlAddress.data.adres_id;
      }
    }

    addresses.push(newAddress);
    saveUserData(addressesKey, addresses);
    renderProfile();
  });

  profileRoot.querySelectorAll("[data-address-id]").forEach((button) => {
    button.addEventListener("click", async () => {
      const id = Number(button.dataset.addressId);
      const addresses = readUserData(addressesKey);
      const address = addresses.find((item) => item.id === id);

      if (getCurrentUserId() && address?.sqlId) {
        await sqlRequest("adres_sil", sqlUserPayload({
          adres_id: address.sqlId,
        }));
      }

      saveUserData(addressesKey, addresses.filter((item) => item.id !== id));
      renderProfile();
    });
  });

  profileRoot.querySelector(".card-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const cardNumber = String(formData.get("cardNumber") || "").replace(/\D/g, "");

    if (cardNumber.length < 4) {
      alert("Kart numarası en az 4 hane olmalı.");
      return;
    }

    const cards = readUserData(cardsKey);
    const newCard = {
      id: Date.now(),
      cardName: String(formData.get("cardName") || "").trim(),
      last4: cardNumber.slice(-4),
    };

    if (getCurrentUserId()) {
      const sqlCard = await sqlRequest("kart_ekle", sqlUserPayload({
        kart_sahibi: newCard.cardName,
        son_dort_hane: newCard.last4,
      }));

      if (sqlCard.success) {
        newCard.sqlId = sqlCard.data.kart_id;
      }
    }

    cards.push(newCard);
    saveUserData(cardsKey, cards);
    renderProfile();
  });

  profileRoot.querySelectorAll("[data-card-id]").forEach((button) => {
    button.addEventListener("click", async () => {
      const id = Number(button.dataset.cardId);
      const cards = readUserData(cardsKey);
      const card = cards.find((item) => item.id === id);

      if (getCurrentUserId() && card?.sqlId) {
        await sqlRequest("kart_sil", sqlUserPayload({
          kart_id: card.sqlId,
        }));
      }

      saveUserData(cardsKey, cards.filter((item) => item.id !== id));
      renderProfile();
    });
  });

  profileRoot.querySelectorAll("[data-favorite-id]").forEach((button) => {
    button.addEventListener("click", () => toggleFavorite(button.dataset.favoriteId));
  });
}

function renderSuccessPage() {
  if (!successRoot) {
    return;
  }

  if (!getCurrentUser()) {
    successRoot.innerHTML = `
      <section class="page-hero compact">
        <p class="eyebrow">Sipariş alındı</p>
        <h1>Önce giriş yapmalısınız</h1>
        <p>Sipariş detayını görmek için hesabınıza giriş yapın.</p>
        <a class="button primary" href="kayit.html">Giriş yap</a>
      </section>
    `;
    return;
  }

  const params = new URLSearchParams(window.location.search);
  const orderNo = params.get("order");
  const orders = readUserData(ordersKey);
  const order = orders.find((item) => item.no === orderNo) || orders[0];

  if (!order) {
    successRoot.innerHTML = `
      <section class="page-hero compact">
        <p class="eyebrow">Sipariş alındı</p>
        <h1>Sipariş bulunamadı</h1>
        <p>Henüz kayıtlı bir sipariş görünmüyor.</p>
        <a class="button primary" href="anasayfa.html#products">Alışverişe dön</a>
      </section>
    `;
    return;
  }

  successRoot.innerHTML = `
    <section class="success-page">
      <div class="success-card">
        <span class="success-icon">✓</span>
        <p class="eyebrow">Sipariş alındı</p>
        <h1>Teşekkürler, siparişiniz oluşturuldu.</h1>
        <p>Siparişiniz profilinizdeki <strong>Siparişlerim</strong> alanına kaydedildi.</p>

        <div class="success-info-grid">
          <div>
            <span>Sipariş No</span>
            <strong>${safeText(order.no)}</strong>
          </div>
          <div>
            <span>Tarih</span>
            <strong>${safeText(order.date)}</strong>
          </div>
          <div>
            <span>Durum</span>
            <strong>${safeText(order.status || "Hazırlanıyor")}</strong>
          </div>
          <div>
            <span>Toplam</span>
            <strong>${formatPrice(order.total || 0)}</strong>
          </div>
        </div>

        <div class="success-order-list">
          <h2>Ürünler</h2>
          ${order.items
            .map(
              (item) => `
                <div class="success-order-item">
                  <span>${orderItemText(item)}</span>
                  <strong>${formatPrice(item.salePrice || salePrice(item))}</strong>
                </div>
              `
            )
            .join("")}
        </div>

        <div class="success-total-lines">
          <div><span>Ara toplam</span><strong>${formatPrice(order.subtotal || 0)}</strong></div>
          ${
            order.discount
              ? `<div><span>Kupon indirimi ${order.coupon ? `(${safeText(order.coupon.code)})` : ""}</span><strong>-${formatPrice(order.discount)}</strong></div>`
              : ""
          }
          <div><span>Kargo</span><strong>${formatPrice(order.shipping || shippingPrice)}</strong></div>
          ${
            order.paymentFee
              ? `<div><span>Kapıda ödeme işlem bedeli</span><strong>${formatPrice(order.paymentFee)}</strong></div>`
              : ""
          }
          <div class="success-grand-total"><span>Genel toplam</span><strong>${formatPrice(order.total || 0)}</strong></div>
        </div>

        <div class="success-actions">
          <a class="button primary" href="profil.html#siparislerim">Siparişlerime git</a>
          <a class="button secondary" href="anasayfa.html#products">Alışverişe devam et</a>
        </div>
      </div>
    </section>
  `;
}

function applySearchFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const query = params.get("search") || params.get("q") || "";

  if (!query) {
    return;
  }

  searchForms.forEach((form) => {
    const input = form.querySelector('input[name="q"]');
    if (input) {
      input.value = query;
    }
  });

  renderProducts(activeFilter, query);
  document.querySelector("#products")?.scrollIntoView();
}

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    filterButtons.forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    renderProducts(button.dataset.filter, activeSearchTerm);
  });
});

searchForms.forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const query = form.querySelector('input[name="q"]')?.value.trim() || "";

    if (grid) {
      renderProducts(activeFilter, query);
      document.querySelector("#products")?.scrollIntoView({ behavior: "smooth" });
      return;
    }

    window.location.href = `anasayfa.html?search=${encodeURIComponent(query)}#products`;
  });
});

const contactForm = document.querySelector(".contact-form");

if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    alert("Mesajınız alındı. Bu form okul projesi için çalışır.");
  });
}


const loginForm = document.querySelector(".login-form");

if (loginForm) {
  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const formData = new FormData(loginForm);
    const username = String(formData.get("username") || "").trim();
    const password = String(formData.get("password") || "");
    const message = document.querySelector("#login-message");

    message.textContent = "Giriş bilgileri SQL üzerinden kontrol ediliyor...";

    const sqlLogin = await sqlRequest("giris", {
      kullanici_adi: username,
      sifre: password,
    });

    if (sqlLogin.success) {
      setCurrentUser(sqlLogin.data.kullanici_adi || username, sqlLogin.data.kullanici_id);
      message.textContent = "Giriş başarılı. Profil sayfanıza yönlendiriliyorsunuz.";
      updateAuthLinks();

      setTimeout(() => {
        window.location.href = "profil.html";
      }, 900);
      return;
    }

    message.textContent = sqlLogin.offline
      ? "SQL bağlantısı kurulamadı. Siteyi localhost üzerinden açmalısın."
      : (sqlLogin.message || "Kullanıcı adı veya şifre hatalı.");
  });
}

const registerForm = document.querySelector(".register-form");

if (registerForm) {
  registerForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const formData = new FormData(registerForm);
    const username = String(formData.get("username") || "").trim();
    const password = String(formData.get("password") || "");
    const message = document.querySelector("#register-message");

    if (!username || !password) {
      message.textContent = "Kullanıcı adı ve şifre alanları boş bırakılamaz.";
      return;
    }

    message.textContent = "Kayıt SQL veritabanına gönderiliyor...";

    const sqlRegister = await sqlRequest("kayit", {
      kullanici_adi: username,
      eposta: "",
      sifre: password,
    });

    if (!sqlRegister.success) {
      message.textContent = sqlRegister.offline
        ? "SQL bağlantısı kurulamadı. Siteyi localhost üzerinden açtığından emin ol."
        : (sqlRegister.message || "Kayıt SQL tablosuna eklenemedi.");
      return;
    }

    const users = readUsers();
    const oldUserIndex = users.findIndex((item) => item.username === username);
    const userRecord = {
      username,
      password,
      sqlId: sqlRegister.data.kullanici_id,
    };

    if (oldUserIndex >= 0) {
      users[oldUserIndex] = userRecord;
    } else {
      users.push(userRecord);
    }

    saveUsers(users);
    setCurrentUser(username, sqlRegister.data.kullanici_id);
    message.textContent = "Kayıt başarılı. Kullanıcı phpMyAdmin'deki kullanicilar tablosuna eklendi.";
    updateAuthLinks();

    setTimeout(() => {
      window.location.href = "profil.html";
    }, 900);
  });
}

function setupCheckoutSteps() {
  const continueButton = document.querySelector("#continue-to-payment");
  const addressStep = document.querySelector("#address-step");
  const shippingStep = document.querySelector("#shipping-step");
  const paymentStep = document.querySelector("#payment-step");

  if (!continueButton || !addressStep || !shippingStep || !paymentStep) {
    return;
  }

  continueButton.addEventListener("click", () => {
    const requiredFields = addressStep.querySelectorAll("input[required], select[required]");
    const isValid = Array.from(requiredFields).every((field) => field.checkValidity());

    if (!isValid) {
      requiredFields.forEach((field) => field.reportValidity());
      return;
    }

    shippingStep.classList.add("is-done");
    paymentStep.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

renderProducts();
renderProductDetail();
applySearchFromUrl();
renderCart();
renderCheckout();
renderProfile();
renderSuccessPage();
updateAuthLinks();

setupCheckoutSteps();
setupCouponForms();


function setupPaymentForm() {
  const paymentForm = document.querySelector("#payment-form");
  const paymentMessage = document.querySelector("#payment-message");
  const cardFields = ["#card-number", "#card-name", "#card-date", "#card-cvc"]
    .map((selector) => document.querySelector(selector))
    .filter(Boolean);

  if (!paymentForm || paymentForm.dataset.ready === "true") {
    return;
  }

  paymentForm.dataset.ready = "true";

  document.querySelectorAll('input[name="payment-method"]').forEach((radio) => {
    radio.addEventListener("change", () => {
      const cashSelected = document.querySelector('input[name="payment-method"]:checked')?.closest(".cash-option");
      cardFields.forEach((field) => {
        field.required = !cashSelected;
      });
      renderCheckout();
    });
  });

  paymentForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (cart.length === 0) {
      if (paymentMessage) {
        paymentMessage.textContent = "Sepetiniz boş olduğu için sipariş oluşturulamadı.";
      }
      return;
    }

    if (!getCurrentUser()) {
      if (paymentMessage) {
        paymentMessage.textContent = "Siparişi profilinizde görmek için önce giriş yapmalısınız.";
      }
      setTimeout(() => {
        window.location.href = "kayit.html";
      }, 700);
      return;
    }

    if (!paymentForm.checkValidity()) {
      paymentForm.reportValidity();
      return;
    }

    const paymentMethod = document.querySelector('input[name="payment-method"]:checked');
    const cashSelected = paymentMethod && paymentMethod.closest(".cash-option");
    const extraFee = cashSelected ? cashPaymentFee : 0;
    const coupon = activeCoupon();
    const discount = couponDiscountAmount();
    const subtotal = cartSum();
    const orders = readUserData(ordersKey);
    const now = Date.now();

    const order = {
      id: now,
      no: `BW-${String(now).slice(-6)}`,
      date: new Date().toLocaleDateString("tr-TR"),
      items: cart.map((item) => ({
        ...item,
        salePrice: salePrice(item),
      })),
      address: {
        name: document.querySelector("#checkout-name")?.value || "",
        surname: document.querySelector("#checkout-surname")?.value || "",
        email: document.querySelector("#checkout-email")?.value || "",
        city: document.querySelector("#checkout-city")?.value || "",
        district: document.querySelector("#checkout-district")?.value || "",
        detail: document.querySelector("#checkout-address")?.value || "",
        phone: document.querySelector("#checkout-phone")?.value || "",
      },
      subtotal,
      coupon: coupon ? { code: coupon.code, title: coupon.title } : null,
      discount,
      shipping: shippingPrice,
      paymentFee: extraFee,
      total: Math.max(0, subtotal - discount) + shippingPrice + extraFee,
      paymentType: cashSelected ? "Kapıda ödeme" : "Kredi kartı",
      status: "Hazırlanıyor",
    };

    if (getCurrentUserId()) {
      const sqlOrder = await sqlRequest("siparis_olustur", sqlUserPayload({
        ara_toplam: subtotal,
        kupon_kodu: coupon ? coupon.code : "",
        indirim_tutari: discount,
        kargo_ucreti: shippingPrice,
        odeme_ucreti: extraFee,
        toplam_tutar: order.total,
        odeme_tipi: order.paymentType,
        items: cart.map((item) => ({
          urun_kodu: item.id,
          urun_adi: item.name,
          beden_numara: item.size || "",
          adet: 1,
          birim_fiyat: salePrice(item),
        })),
      }));

      if (sqlOrder.success) {
        order.sqlId = sqlOrder.data.siparis_id;
        order.no = sqlOrder.data.siparis_no;
      }
    }

    saveUserData(ordersKey, [order, ...orders]);

    cart = [];
    saveCart();
    localStorage.removeItem(couponKey);
    renderCart();
    renderCheckout();

    if (paymentMessage) {
      paymentMessage.textContent = "Siparişiniz başarıyla oluşturuldu. Sipariş alındı sayfasına yönlendiriliyorsunuz.";
    }

    setTimeout(() => {
      window.location.href = `siparis.html?order=${encodeURIComponent(order.no)}`;
    }, 700);
  });
}


setupPaymentForm();
