<?php
/*
Hasan Danacı-262484023
Halil İbrahim Bulut-262484048
*/

header("Content-Type: application/json; charset=utf-8");
require_once "db.php";

$action = $_GET["action"] ?? "";

function body_json() {
    $raw = file_get_contents("php://input");
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function response_json($success, $message, $data = []) {
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "data" => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function product_id_from_code($db, $code) {
    $stmt = $db->prepare("SELECT urun_id FROM urunler WHERE urun_kodu = ? LIMIT 1");
    $stmt->execute([$code]);
    $row = $stmt->fetch();
    return $row ? intval($row["urun_id"]) : 0;
}

if ($action === "urunler") {
    $stmt = $db->query("SELECT * FROM urunler WHERE aktif = 1 ORDER BY urun_id DESC");
    response_json(true, "Ürünler listelendi.", $stmt->fetchAll());
}

if ($action === "kupon") {
    $code = strtoupper(trim($_GET["code"] ?? ""));
    $stmt = $db->prepare("SELECT * FROM kuponlar WHERE kupon_kodu = ? AND aktif = 1");
    $stmt->execute([$code]);
    $coupon = $stmt->fetch();

    if (!$coupon) {
        response_json(false, "Kupon kodu geçersiz.");
    }

    response_json(true, "Kupon bulundu.", $coupon);
}

if ($action === "kayit") {
    $data = body_json();
    $kullaniciAdi = trim($data["kullanici_adi"] ?? "");
    $eposta = trim($data["eposta"] ?? "");
    $sifre = trim($data["sifre"] ?? "");

    if ($kullaniciAdi === "" || $sifre === "") {
        response_json(false, "Kullanıcı adı ve şifre zorunludur.");
    }

    $hash = password_hash($sifre, PASSWORD_DEFAULT);

    try {
        $stmt = $db->prepare("INSERT INTO kullanicilar (kullanici_adi, eposta, sifre) VALUES (?, ?, ?)");
        $stmt->execute([$kullaniciAdi, $eposta, $hash]);

        response_json(true, "Kayıt başarılı.", [
            "kullanici_id" => intval($db->lastInsertId()),
            "kullanici_adi" => $kullaniciAdi
        ]);
    } catch (PDOException $e) {
        response_json(false, "Bu kullanıcı adı zaten kayıtlı olabilir.", [
            "error" => $e->getMessage()
        ]);
    }
}

if ($action === "giris") {
    $data = body_json();
    $kullaniciAdi = trim($data["kullanici_adi"] ?? "");
    $sifre = trim($data["sifre"] ?? "");

    $stmt = $db->prepare("SELECT * FROM kullanicilar WHERE kullanici_adi = ?");
    $stmt->execute([$kullaniciAdi]);
    $user = $stmt->fetch();

    if (!$user) {
        response_json(false, "Kullanıcı adı veya şifre hatalı.");
    }

    $hashDogru = password_verify($sifre, $user["sifre"]);
    $duzSifreDogru = $sifre === $user["sifre"];

    if (!$hashDogru && !$duzSifreDogru) {
        response_json(false, "Kullanıcı adı veya şifre hatalı.");
    }

    response_json(true, "Giriş başarılı.", [
        "kullanici_id" => intval($user["kullanici_id"]),
        "kullanici_adi" => $user["kullanici_adi"]
    ]);
}

if ($action === "sepet_ekle") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $urunKodu = trim($data["urun_kodu"] ?? "");
    $beden = trim($data["beden_numara"] ?? "");
    $adet = max(1, intval($data["adet"] ?? 1));
    $urunId = product_id_from_code($db, $urunKodu);

    if ($kullaniciId <= 0 || $urunId <= 0) {
        response_json(false, "Sepet için kullanıcı veya ürün bilgisi eksik.");
    }

    $stmt = $db->prepare("INSERT INTO sepet (kullanici_id, urun_id, beden_numara, adet) VALUES (?, ?, ?, ?)");
    $stmt->execute([$kullaniciId, $urunId, $beden, $adet]);

    response_json(true, "Ürün sepete SQL üzerinden eklendi.", [
        "sepet_id" => intval($db->lastInsertId())
    ]);
}

if ($action === "sepet_sil") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $urunKodu = trim($data["urun_kodu"] ?? "");
    $beden = trim($data["beden_numara"] ?? "");
    $urunId = product_id_from_code($db, $urunKodu);

    if ($kullaniciId <= 0 || $urunId <= 0) {
        response_json(false, "Sepetten silmek için kullanıcı veya ürün bilgisi eksik.");
    }

    $stmt = $db->prepare("
        DELETE FROM sepet
        WHERE kullanici_id = ? AND urun_id = ? AND IFNULL(beden_numara, '') = ?
        ORDER BY sepet_id DESC
        LIMIT 1
    ");
    $stmt->execute([$kullaniciId, $urunId, $beden]);

    response_json(true, "Ürün sepetten silindi.");
}

if ($action === "favori_ekle") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $urunKodu = trim($data["urun_kodu"] ?? "");
    $urunId = product_id_from_code($db, $urunKodu);

    if ($kullaniciId <= 0 || $urunId <= 0) {
        response_json(false, "Favori için kullanıcı veya ürün bilgisi eksik.");
    }

    $stmt = $db->prepare("INSERT IGNORE INTO favoriler (kullanici_id, urun_id) VALUES (?, ?)");
    $stmt->execute([$kullaniciId, $urunId]);

    response_json(true, "Ürün favorilere SQL üzerinden eklendi.");
}

if ($action === "favori_sil") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $urunKodu = trim($data["urun_kodu"] ?? "");
    $urunId = product_id_from_code($db, $urunKodu);

    if ($kullaniciId <= 0 || $urunId <= 0) {
        response_json(false, "Favori silmek için kullanıcı veya ürün bilgisi eksik.");
    }

    $stmt = $db->prepare("DELETE FROM favoriler WHERE kullanici_id = ? AND urun_id = ?");
    $stmt->execute([$kullaniciId, $urunId]);

    response_json(true, "Ürün favorilerden SQL üzerinden silindi.");
}

if ($action === "adres_ekle") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $adSoyad = trim($data["ad_soyad"] ?? "");
    $telefon = trim($data["telefon"] ?? "");
    $il = trim($data["il"] ?? "");
    $ilce = trim($data["ilce"] ?? "");
    $adresDetay = trim($data["adres_detay"] ?? "");

    if ($kullaniciId <= 0 || $adresDetay === "") {
        response_json(false, "Adres için kullanıcı ve adres detayı gereklidir.");
    }

    $stmt = $db->prepare("
        INSERT INTO adresler (kullanici_id, ad_soyad, telefon, il, ilce, adres_detay)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$kullaniciId, $adSoyad, $telefon, $il, $ilce, $adresDetay]);

    response_json(true, "Adres SQL tablosuna kaydedildi.", [
        "adres_id" => intval($db->lastInsertId())
    ]);
}

if ($action === "adres_sil") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $adresId = intval($data["adres_id"] ?? 0);

    if ($kullaniciId <= 0 || $adresId <= 0) {
        response_json(false, "Adres silmek için gerekli bilgiler eksik.");
    }

    $stmt = $db->prepare("DELETE FROM adresler WHERE adres_id = ? AND kullanici_id = ?");
    $stmt->execute([$adresId, $kullaniciId]);

    response_json(true, "Adres SQL tablosundan silindi.");
}

if ($action === "kart_ekle") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $kartSahibi = trim($data["kart_sahibi"] ?? "");
    $sonDort = preg_replace("/\D/", "", $data["son_dort_hane"] ?? "");
    $sonDort = substr($sonDort, -4);

    if ($kullaniciId <= 0 || strlen($sonDort) !== 4) {
        response_json(false, "Kart için kullanıcı ve son 4 hane gereklidir.");
    }

    $stmt = $db->prepare("INSERT INTO kartlar (kullanici_id, kart_sahibi, son_dort_hane) VALUES (?, ?, ?)");
    $stmt->execute([$kullaniciId, $kartSahibi, $sonDort]);

    response_json(true, "Kart SQL tablosuna kaydedildi.", [
        "kart_id" => intval($db->lastInsertId())
    ]);
}

if ($action === "kart_sil") {
    $data = body_json();
    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $kartId = intval($data["kart_id"] ?? 0);

    if ($kullaniciId <= 0 || $kartId <= 0) {
        response_json(false, "Kart silmek için gerekli bilgiler eksik.");
    }

    $stmt = $db->prepare("DELETE FROM kartlar WHERE kart_id = ? AND kullanici_id = ?");
    $stmt->execute([$kartId, $kullaniciId]);

    response_json(true, "Kart SQL tablosundan silindi.");
}

if ($action === "siparis_olustur") {
    $data = body_json();

    $kullaniciId = intval($data["kullanici_id"] ?? 0);
    $items = $data["items"] ?? [];
    $araToplam = floatval($data["ara_toplam"] ?? 0);
    $kuponKodu = $data["kupon_kodu"] ?? null;
    $indirim = floatval($data["indirim_tutari"] ?? 0);
    $kargo = floatval($data["kargo_ucreti"] ?? 130);
    $odemeUcreti = floatval($data["odeme_ucreti"] ?? 0);
    $toplam = floatval($data["toplam_tutar"] ?? 0);
    $odemeTipi = $data["odeme_tipi"] ?? "Kredi kartı";

    if ($kullaniciId <= 0 || count($items) === 0) {
        response_json(false, "Sipariş için kullanıcı ve ürün bilgisi gereklidir.");
    }

    $siparisNo = "BW-" . time();

    $db->beginTransaction();

    try {
        $stmt = $db->prepare("
            INSERT INTO siparisler
            (siparis_no, kullanici_id, ara_toplam, kupon_kodu, indirim_tutari, kargo_ucreti, odeme_ucreti, toplam_tutar, odeme_tipi)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$siparisNo, $kullaniciId, $araToplam, $kuponKodu, $indirim, $kargo, $odemeUcreti, $toplam, $odemeTipi]);
        $siparisId = intval($db->lastInsertId());

        $detay = $db->prepare("
            INSERT INTO siparis_detaylari
            (siparis_id, urun_id, urun_adi, beden_numara, adet, birim_fiyat)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        foreach ($items as $item) {
            $urunId = product_id_from_code($db, $item["urun_kodu"] ?? "");
            if ($urunId <= 0) {
                continue;
            }

            $detay->execute([
                $siparisId,
                $urunId,
                $item["urun_adi"] ?? "",
                $item["beden_numara"] ?? "",
                intval($item["adet"] ?? 1),
                floatval($item["birim_fiyat"] ?? 0)
            ]);
        }

        $temizle = $db->prepare("DELETE FROM sepet WHERE kullanici_id = ?");
        $temizle->execute([$kullaniciId]);

        $db->commit();

        response_json(true, "Sipariş SQL tablosuna kaydedildi.", [
            "siparis_id" => $siparisId,
            "siparis_no" => $siparisNo
        ]);
    } catch (Exception $e) {
        $db->rollBack();
        response_json(false, "Sipariş oluşturulamadı.", [
            "error" => $e->getMessage()
        ]);
    }
}

if ($action === "siparisler") {
    $kullaniciId = intval($_GET["kullanici_id"] ?? 0);

    if ($kullaniciId <= 0) {
        response_json(false, "Kullanıcı ID gerekli.");
    }

    $stmt = $db->prepare("SELECT * FROM siparisler WHERE kullanici_id = ? ORDER BY siparis_id DESC");
    $stmt->execute([$kullaniciId]);

    response_json(true, "Siparişler listelendi.", $stmt->fetchAll());
}

response_json(false, "Geçersiz işlem.");
?>
