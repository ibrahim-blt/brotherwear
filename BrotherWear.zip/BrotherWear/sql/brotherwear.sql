/*Hasan Danacı-262484023
Halil İbrahim Bulut-262484048
*/

CREATE DATABASE IF NOT EXISTS brotherwear
CHARACTER SET utf8mb4
COLLATE utf8mb4_turkish_ci;

USE brotherwear;

CREATE TABLE IF NOT EXISTS kullanicilar (
  kullanici_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_adi VARCHAR(60) NOT NULL UNIQUE,
  eposta VARCHAR(120),
  sifre VARCHAR(255) NOT NULL,
  kayit_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS urunler (
  urun_id INT AUTO_INCREMENT PRIMARY KEY,
  urun_kodu VARCHAR(80) NOT NULL UNIQUE,
  urun_adi VARCHAR(120) NOT NULL,
  kategori VARCHAR(50) NOT NULL,
  etiket VARCHAR(50) NOT NULL,
  fiyat DECIMAL(10,2) NOT NULL,
  renk VARCHAR(60),
  fotograf_1 VARCHAR(255),
  fotograf_2 VARCHAR(255),
  aktif TINYINT(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS urun_numaralari (
  numara_id INT AUTO_INCREMENT PRIMARY KEY,
  urun_id INT NOT NULL,
  numara VARCHAR(10) NOT NULL,
  stok INT DEFAULT 10,
  FOREIGN KEY (urun_id) REFERENCES urunler(urun_id) ON DELETE CASCADE,
  UNIQUE KEY tek_numara (urun_id, numara)
);

CREATE TABLE IF NOT EXISTS sepet (
  sepet_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  urun_id INT NOT NULL,
  beden_numara VARCHAR(10),
  adet INT DEFAULT 1,
  eklenme_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id) ON DELETE CASCADE,
  FOREIGN KEY (urun_id) REFERENCES urunler(urun_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS siparisler (
  siparis_id INT AUTO_INCREMENT PRIMARY KEY,
  siparis_no VARCHAR(40) NOT NULL UNIQUE,
  kullanici_id INT NOT NULL,
  ara_toplam DECIMAL(10,2) NOT NULL,
  kupon_kodu VARCHAR(40),
  indirim_tutari DECIMAL(10,2) DEFAULT 0,
  kargo_ucreti DECIMAL(10,2) DEFAULT 130,
  odeme_ucreti DECIMAL(10,2) DEFAULT 0,
  toplam_tutar DECIMAL(10,2) NOT NULL,
  odeme_tipi VARCHAR(40),
  durum VARCHAR(50) DEFAULT 'Hazırlanıyor',
  siparis_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS siparis_detaylari (
  detay_id INT AUTO_INCREMENT PRIMARY KEY,
  siparis_id INT NOT NULL,
  urun_id INT NOT NULL,
  urun_adi VARCHAR(120) NOT NULL,
  beden_numara VARCHAR(10),
  adet INT DEFAULT 1,
  birim_fiyat DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (siparis_id) REFERENCES siparisler(siparis_id) ON DELETE CASCADE,
  FOREIGN KEY (urun_id) REFERENCES urunler(urun_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS adresler (
  adres_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  ad_soyad VARCHAR(120),
  telefon VARCHAR(25),
  il VARCHAR(60),
  ilce VARCHAR(60),
  adres_detay VARCHAR(255),
  FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS favoriler (
  favori_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  urun_id INT NOT NULL,
  FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id) ON DELETE CASCADE,
  FOREIGN KEY (urun_id) REFERENCES urunler(urun_id) ON DELETE CASCADE,
  UNIQUE KEY tek_favori (kullanici_id, urun_id)
);

CREATE TABLE IF NOT EXISTS kartlar (
  kart_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  kart_sahibi VARCHAR(120),
  son_dort_hane VARCHAR(4),
  FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS kuponlar (
  kupon_id INT AUTO_INCREMENT PRIMARY KEY,
  kupon_kodu VARCHAR(40) NOT NULL UNIQUE,
  indirim_yuzdesi INT NOT NULL,
  aktif TINYINT(1) DEFAULT 1
);

INSERT INTO kuponlar (kupon_kodu, indirim_yuzdesi, aktif) VALUES
('BROTHER20', 20, 1),
('HOSGELDIN10', 10, 1),
('OKUL15', 15, 1)
ON DUPLICATE KEY UPDATE indirim_yuzdesi = VALUES(indirim_yuzdesi), aktif = VALUES(aktif);

INSERT INTO urunler (urun_kodu, urun_adi, kategori, etiket, fiyat, renk, fotograf_1, fotograf_2) VALUES
('nike-air-force-1-beyaz', 'Nike Air Force 1 Beyaz', 'ayakkabi', 'Ayakkabı', 2499, 'Beyaz', 'assets/nike-air-force-1-beyaz-1.webp', 'assets/nike-air-force-1-beyaz-2.webp'),
('adidas-campus-00s', 'Adidas Campus 00''s', 'ayakkabi', 'Ayakkabı', 2499, 'Siyah', 'assets/adidas-campus-00s-1.webp', 'assets/adidas-campus-00s-2.webp'),
('nike-dunk-low-panda', 'Nike Dunk Low Panda', 'ayakkabi', 'Ayakkabı', 2499, 'Siyah / beyaz', 'assets/nike-dunk-low-panda-1.webp', 'assets/nike-dunk-low-panda-2.webp'),
('adidas-yeezy-700-v3', 'Adidas Yeezy 700 V3', 'ayakkabi', 'Ayakkabı', 2499, 'Krem / beyaz', 'assets/adidas-yeezy-700-v3-1.webp', 'assets/adidas-yeezy-700-v3-2.webp'),
('nike-siyah-tisort', 'Nike Siyah Tişört', 'tisort', 'Tişört', 279, 'Siyah', 'assets/nike-siyah-tisort-1.webp', 'assets/nike-siyah-tisort-2.webp'),
('nike-beyaz-tisort', 'Nike Beyaz Tişört', 'tisort', 'Tişört', 279, 'Beyaz', 'assets/nike-beyaz-tisort-1.webp', 'assets/nike-beyaz-tisort-2.webp'),
('nike-tm-tisort', 'Nike TM Tişört', 'tisort', 'Tişört', 279, 'Siyah', 'assets/nike-tm-tisort-1.webp', 'assets/nike-tm-tisort-2.webp'),
('nike-tm2-tisort', 'Nike TM2 Tişört', 'tisort', 'Tişört', 279, 'Beyaz', 'assets/nike-tm2-tisort-1.webp', 'assets/nike-tm2-tisort-2.webp'),
('nike-siyah-sort', 'Nike Siyah Şort', 'sort', 'Şort', 499, 'Siyah', 'assets/nike-siyah-sort-1.webp', 'assets/nike-siyah-sort-2.webp'),
('nike-gri-sort', 'Nike Gri Şort', 'sort', 'Şort', 499, 'Gri', 'assets/nike-gri-sort-1.webp', 'assets/nike-gri-sort-2.webp'),
('nike-jordan-siyah-sort', 'Nike Jordan Siyah Şort', 'sort', 'Şort', 499, 'Siyah', 'assets/nike-jordan-siyah-sort-1.webp', 'assets/nike-jordan-siyah-sort-2.webp'),
('nike-tm-sort', 'Nike TM Şort', 'sort', 'Şort', 499, 'Gri', 'assets/nike-tm-sort-1.webp', 'assets/nike-tm-sort-2.webp'),
('nike-siyah-sweatshirt', 'Nike Siyah Sweatshirt', 'sweatshirt', 'Sweatshirt', 599, 'Siyah', 'assets/nike-siyah-sweatshirt-1.webp', 'assets/nike-siyah-sweatshirt-2.webp'),
('nike-gri-sweatshirt', 'Nike Gri Sweatshirt', 'sweatshirt', 'Sweatshirt', 599, 'Gri', 'assets/nike-gri-sweatshirt-1.webp', 'assets/nike-gri-sweatshirt-2.webp'),
('nike-tm-siyah-sweatshirt', 'Nike TM Siyah Sweatshirt', 'sweatshirt', 'Sweatshirt', 599, 'Siyah', 'assets/nike-tm-siyah-sweatshirt-1.webp', 'assets/nike-tm-siyah-sweatshirt-2.webp'),
('nike-tm-gri-sweatshirt', 'Nike TM Gri Sweatshirt', 'sweatshirt', 'Sweatshirt', 599, 'Gri', 'assets/nike-tm-gri-sweatshirt-1.webp', 'assets/nike-tm-gri-sweatshirt-2.webp'),
('baggy-siyah-pantolon', 'Baggy Siyah Pantolon', 'pantolon', 'Pantolon', 749, 'Siyah', 'assets/p1.webp', 'assets/p1.webp'),
('baggy-buz-mavisi-pantolon', 'Baggy Buz Mavisi Pantolon', 'pantolon', 'Pantolon', 749, 'Buz mavisi', 'assets/p2.webp', 'assets/p2.webp'),
('baggy-antrasit-pantolon', 'Baggy Antrasit Pantolon', 'pantolon', 'Pantolon', 749, 'Antrasit', 'assets/p3.webp', 'assets/p3.webp'),
('baggy-mavi-pantolon', 'Baggy Mavi Pantolon', 'pantolon', 'Pantolon', 749, 'Mavi', 'assets/p4.webp', 'assets/p4.webp'),
('nike-siyah-esofman', 'Nike Siyah Eşofman', 'esofman', 'Eşofman', 749, 'Siyah', 'assets/nike-siyah-esofman-1.webp', 'assets/nike-siyah-esofman-2.webp'),
('nike-gri-esofman', 'Nike Gri Eşofman', 'esofman', 'Eşofman', 749, 'Gri', 'assets/nike-gri-esofman-1.webp', 'assets/nike-gri-esofman-2.webp'),
('nike-gri-siyah-esofman', 'Nike Gri-Siyah Eşofman', 'esofman', 'Eşofman', 749, 'Gri / siyah', 'assets/nike-gri-siyah-esofman-1.webp', 'assets/nike-gri-siyah-esofman-2.webp'),
('nike-pembe-esofman', 'Nike Pembe Eşofman', 'esofman', 'Eşofman', 749, 'Pembe', 'assets/nike-pembe-esofman-1.webp', 'assets/nike-pembe-esofman-2.webp'),
('nike-siyah-ceket', 'Nike Siyah Ceket', 'ceket', 'Ceket', 999, 'Siyah', 'assets/nike-siyah-ceket-1.webp', 'assets/nike-siyah-ceket-2.webp'),
('adidas-siyah-ceket', 'Adidas Siyah Ceket', 'ceket', 'Ceket', 999, 'Siyah', 'assets/adidas-siyah-ceket-1.webp', 'assets/adidas-siyah-ceket-2.webp'),
('nike-siyah-mont', 'Nike Siyah Mont', 'mont', 'Mont', 1499, 'Siyah', 'assets/nike-siyah-mont-1.webp', 'assets/nike-siyah-mont-2.webp'),
('nike-gri-beyaz-mont', 'Nike Gri-Beyaz Mont', 'mont', 'Mont', 1499, 'Gri / beyaz', 'assets/nike-gri-beyaz-mont-1.webp', 'assets/nike-gri-beyaz-mont-2.webp')

ON DUPLICATE KEY UPDATE
  urun_adi = VALUES(urun_adi),
  kategori = VALUES(kategori),
  etiket = VALUES(etiket),
  fiyat = VALUES(fiyat),
  renk = VALUES(renk),
  fotograf_1 = VALUES(fotograf_1),
  fotograf_2 = VALUES(fotograf_2),
  aktif = 1;

INSERT INTO urun_numaralari (urun_id, numara, stok)
SELECT u.urun_id, n.numara, 10
FROM urunler u
JOIN (
  SELECT '36' AS numara UNION SELECT '37' UNION SELECT '38' UNION SELECT '39' UNION SELECT '40'
  UNION SELECT '41' UNION SELECT '42' UNION SELECT '43' UNION SELECT '44' UNION SELECT '45'
) n
WHERE u.kategori = 'ayakkabi'
ON DUPLICATE KEY UPDATE stok = VALUES(stok);

INSERT INTO urun_numaralari (urun_id, numara, stok)
SELECT u.urun_id, n.numara, 10
FROM urunler u
JOIN (SELECT 'S' AS numara UNION SELECT 'M' UNION SELECT 'L' UNION SELECT 'XL') n
WHERE u.kategori <> 'ayakkabi'
ON DUPLICATE KEY UPDATE stok = VALUES(stok);
