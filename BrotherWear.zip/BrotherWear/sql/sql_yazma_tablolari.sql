/* Hasan Danacı-262484023
Halil İbrahim Bulut-262484048
*/

USE brotherwear;

CREATE TABLE IF NOT EXISTS kullanicilar (
  kullanici_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_adi VARCHAR(60) NOT NULL UNIQUE,
  eposta VARCHAR(120),
  sifre VARCHAR(255) NOT NULL,
  kayit_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sepet (
  sepet_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  urun_id INT NOT NULL,
  beden_numara VARCHAR(10),
  adet INT DEFAULT 1,
  eklenme_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS siparisler (
  siparis_id INT AUTO_INCREMENT PRIMARY KEY,
  siparis_no VARCHAR(40) NOT NULL UNIQUE,
  kullanici_id INT NOT NULL,
  ara_toplam DECIMAL(10,2) NOT NULL,
  kupon_kodu VARCHAR(40),
  indirim_tutari DECIMAL(10,2) DEFAULT 0,
  kargo_ucreti DECIMAL(10,2) DEFAULT 130,
  odeme_ucreti DECIMAL(10,2) DEFAULT 0,
  toplam_tutar DECIMAL(10,2) NOT NULL,
  odeme_tipi VARCHAR(40),
  durum VARCHAR(50) DEFAULT 'Hazırlanıyor',
  siparis_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS siparis_detaylari (
  detay_id INT AUTO_INCREMENT PRIMARY KEY,
  siparis_id INT NOT NULL,
  urun_id INT NOT NULL,
  urun_adi VARCHAR(120) NOT NULL,
  beden_numara VARCHAR(10),
  adet INT DEFAULT 1,
  birim_fiyat DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS adresler (
  adres_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  ad_soyad VARCHAR(120),
  telefon VARCHAR(25),
  il VARCHAR(60),
  ilce VARCHAR(60),
  adres_detay VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS favoriler (
  favori_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  urun_id INT NOT NULL,
  UNIQUE KEY tek_favori (kullanici_id, urun_id)
);

CREATE TABLE IF NOT EXISTS kartlar (
  kart_id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  kart_sahibi VARCHAR(120),
  son_dort_hane VARCHAR(4)
);

CREATE TABLE IF NOT EXISTS kuponlar (
  kupon_id INT AUTO_INCREMENT PRIMARY KEY,
  kupon_kodu VARCHAR(40) NOT NULL UNIQUE,
  indirim_yuzdesi INT NOT NULL,
  aktif TINYINT(1) DEFAULT 1
);

INSERT INTO kuponlar (kupon_kodu, indirim_yuzdesi, aktif) VALUES
('BROTHER20', 20, 1),
('HOSGELDIN10', 10, 1),
('OKUL15', 15, 1)
ON DUPLICATE KEY UPDATE indirim_yuzdesi = VALUES(indirim_yuzdesi), aktif = VALUES(aktif);
